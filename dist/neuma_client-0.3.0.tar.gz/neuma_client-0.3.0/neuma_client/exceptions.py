# -*- coding: utf-8 -*-
class NotFoundException(Exception):
    """
    Any error occurring whenever an object is not found
    """
