# neuma-client
Python interface for calling Neuma services

This code is a fork from Teklia's Arkindex api client,
available at https://gitlab.teklia.com/arkindex/api-client/